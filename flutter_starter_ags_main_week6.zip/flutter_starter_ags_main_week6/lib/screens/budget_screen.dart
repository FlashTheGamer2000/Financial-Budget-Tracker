import 'package:flutter/material.dart';

class BudgetScreen extends StatelessWidget {
  const BudgetScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        title: const Text(
          'Budget Details',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Budget Overview',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),
            const SizedBox(height: 12),
            _buildBudgetItem('Monthly Allowance', 'Rp 2.500.000,00', Colors.blue),
            const SizedBox(height: 10),
            _buildBudgetItem('Total Spent', 'Rp 1.500.000,00', Colors.orange),
            const SizedBox(height: 10),
            _buildBudgetItem('Remaining Budget', 'Rp 1.000.000,00', Colors.green),
            const SizedBox(height: 24),
            const Text(
              'Category Allocation',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),
            const SizedBox(height: 12),
            _buildCategoryTile(Icons.fastfood, 'Food & Drinks', 'Rp 800.000'),
            _buildCategoryTile(Icons.directions_bus, 'Transportation', 'Rp 400.000'),
            _buildCategoryTile(Icons.shopping_bag, 'Shopping', 'Rp 300.000'),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetItem(String label, String amount, Color amountColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFCBD5E1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 15, color: Color(0xFF64748B))),
          Text(
            amount,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: amountColor),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryTile(IconData icon, String title, String amount) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
        side: const BorderSide(color: Color(0xFFCBD5E1)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF0E7C86)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: Text(amount, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}